#include<iostream>
#include<string>
#pragma warning(disable:4996)
#include"cuvantCheie.h"
#include <vector>
#include<map>
#include<list>
#include<fstream>
using namespace std;



char transformaTotInLitereMici(char c) {
	if (c <= 'Z' && c >= 'A')
		return c - ('Z' - 'z');
	return c;
}



// 0123456789ABCD
//  CREATE TABLE Persons   ( int, varchar(255), varchar(255), varchar(255), varchar(255))     ;
/*
1. cauta subsirul create intr un sir  si verifica sa fie primul
2. daca ai gasit  create cauta table si vezi sa fie primul dupa create
3. daca ai gasit SI create si Table ... cauta un sir oarecare dupa create table
4.

*/


// id    nume   prenume
// 0      gigel  ion
// 1       ionel  gigi


// CLASA ABSTRACTA 
class IGestiuneTabela {
public:
	virtual void informatiiTabela()=0;
	virtual void  resetare() = 0;

};



class Tabela: public IGestiuneTabela
{

private:


	string numeTabela;
	int nrLinii_nrObiecte = 0;

	int nrColoane; // 4
	string* coloane;// int string string float 
	string* numeColoane=NULL;


	int  nrColoaneString = 0; //2
	string** coloaneString = NULL;//nume prenume

	int nrColoaneFloat = 0; // 1
	float** coloaneFloat = NULL;//  note

	int nrColoaneIntreg = 0;//1
	int** coloaneIntregi = NULL;//id





public:



	/// salvare tabela in fisier binar - taote informatiile si datele din fisier 

	void salvareInBinar(ofstream& o) {

		int m = numeTabela.length() + 1;
		o.write((char*)&m, 4);
		o.write((char*) numeTabela.c_str(), m);


		o.write((char*)&nrLinii_nrObiecte, 4);

		o.write((char*)&nrColoane, 4);

		for (int i = 0; i < nrColoane; i++) {
			int m1 = coloane[i].length() + 1;
			o.write((char*)&m1, 4);
			o.write((char*)coloane[i].c_str(), m1);

		}

		for (int i = 0; i < nrColoane; i++) {
			int m12 = numeColoane[i].length() + 1;
			o.write((char*)&m12, 4);
			o.write((char*)numeColoane[i].c_str(), m12);

		}


		o.write((char*)&nrColoaneFloat, 4);
		for (int i = 0; i < nrColoaneFloat; i++) {
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				o.write((char*)&coloaneFloat[i][j], 4);
			}
		}

		o.write((char*)&nrColoaneIntreg, 4);
		for (int i = 0; i < nrColoaneIntreg; i++) {
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				o.write((char*)&coloaneIntregi[i][j], 4);
			}
		}


		o.write((char*)&nrColoaneString, 4);
		for (int i = 0; i < nrColoaneString; i++) {
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
		
				int m1 = coloaneString[i][j].length() + 1;
				o.write((char*)& m1, 4);
				o.write((char*)coloaneString[i][j].c_str(), m1);

			}
		}




	}


	void preluareDinBinar(ifstream & in) {


		int m =0;
		in.read((char*)&m, 4);
		char buffer[500];
		in.read((char*)buffer, m);
		numeTabela = buffer;

		in.read((char*)&nrLinii_nrObiecte, 4);

		in.read((char*)&nrColoane, 4);

		delete[] coloane;
		delete[] numeColoane;

		coloane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			
			in.read((char*)&m, 4);
		
			in.read((char*)buffer, m);
			coloane[i] = buffer;
		}

		numeColoane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {

			in.read((char*)&m, 4);

			in.read((char*)buffer, m);
			numeColoane[i] = buffer;
		}



		for (int i = 0; i < nrColoaneFloat; i++) {
			if (coloaneFloat[i]) {
				delete[] coloaneFloat[i];
			}
		}



		delete[] coloaneFloat;

		for (int i = 0; i < nrColoaneIntreg; i++) {
			if (coloaneIntregi[i]) {
				delete[] coloaneIntregi[i];
			}
		}
		delete[] coloaneIntregi;

		for (int i = 0; i < nrColoaneString; i++) {
			if (coloaneString[i]) {
				delete[] coloaneString[i];
			}
		}
		delete[] coloaneString;



		in.read((char*)&nrColoaneFloat, 4);
		coloaneFloat = new float*[nrColoaneFloat];
		for (int i = 0; i < nrColoaneFloat; i++) {
			coloaneFloat[i] = new float[nrLinii_nrObiecte];
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				in.read((char*)&coloaneFloat[i][j], 4);
			}
		}


		in.read((char*)&nrColoaneIntreg, 4);
		coloaneIntregi = new int *[nrColoaneIntreg];
		for (int i = 0; i < nrColoaneIntreg; i++) {
			coloaneIntregi[i] = new int [nrLinii_nrObiecte];
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				in.read((char*)&coloaneIntregi[i][j], 4);
			}
		}

		in.read((char*)&nrColoaneString, 4);
		coloaneString = new string *[nrColoaneString];
		for (int i = 0; i < nrColoaneString; i++) {
			coloaneString[i] = new string[nrLinii_nrObiecte];
			for (int j = 0; j < nrLinii_nrObiecte; j++) {
		

				in.read((char*)&m, 4);

				in.read((char*)buffer, m);
				coloaneString[i][j] = buffer;


			}
		}





	}








	Tabela* creareTabela(string x) {

		for (int i = 0; i < x.length(); i++) {
			x[i] = transformaTotInLitereMici(x[i]);
		}


		//int pozitieCreate= x.find("create");
		//bool okCreate = 0;
		////cout << pozitieCreate << endl;
		//int  aparitiiSpatiuPanaInCreate = 0;
		//if (pozitieCreate >= 0) {

		//	for (int i = 0; i < pozitieCreate; i++) {
		//		if (x[i] == ' ') {
		//			aparitiiSpatiuPanaInCreate++;
		//		}
		//	}

		//}
		//if (pozitieCreate == aparitiiSpatiuPanaInCreate) {
		//	okCreate = 1;
		//}


		int pozitePrimaParanteza = -1;
		int pozitieUltimaParanteza = -1;
		int  pozitiePunctSiVirgula = -1;

		for (int i = 0; i < x.length(); i++) {
			if (x[i] == '(') {
				pozitePrimaParanteza = i;
				break;
			}
		}

		for (int i = x.length(); i >= 0; i--) {
			if (x[i] == ')') {
				pozitieUltimaParanteza = i;
				break;
			}
		}

		for (int i = 0; i < x.length(); i++) {
			if (x[i] == ';') {
				pozitiePunctSiVirgula = i;
				break;
			}
		}



		Cuvant create;
		create.create();
		create.setPozitieInComanda(x.find(create.getCuvant()));

		Cuvant table;
		table.table();
		table.setPozitieInComanda(x.find(table.getCuvant()));



		//table.afisareInformatiiCuvantCheie();



		int p = table.getPozitie() + table.getCuvant().length();
		Cuvant numetabela;

		//cout << x[p] << endl;
		char numetabelachar[500];
		int contor_numetabelachar = 0;
		for (int i = p; i < pozitePrimaParanteza; i++) {
			numetabelachar[contor_numetabelachar++] = x[i];
		}
		numetabelachar[contor_numetabelachar] = '\0';

		//cout << numetabelachar << endl;

		int contorCuvinteNumeTabela = 0;
		char sep[] = " .,)";
		char* p1 = strtok(numetabelachar, sep);
		while (p1 != NULL)
		{
			contorCuvinteNumeTabela++;
			p1 = strtok(NULL, sep);
		}

		bool ok_numeTabela = 0;
		if (contorCuvinteNumeTabela == 1) {
			ok_numeTabela = true;
		}


		//cout << numeTabela.length() << endl;

		if (ok_numeTabela == 1) {
			numetabela.setNumeTabela(numetabelachar);
			numetabela.setPozitieInComanda(x.find(numetabelachar));

		}
		//numetabela.afisareInformatiiCuvantCheie();



		int pozitiiVirgule[500];
		int nrvirgule = 0;
		for (int i = pozitePrimaParanteza; i < pozitieUltimaParanteza; i++) {

			if (x[i] == ',') {
				pozitiiVirgule[nrvirgule++] = i;
			}
		}

		//for (int i = 0; i < nrvirgule; i++) {
		////	cout << pozitiiVirgule[i] << endl;
		//}


		char sir_intreParanteze[500];
		char sir_intreParanteze2[500];


		int  k = 0;
		for (int i = pozitePrimaParanteza + 1; i <= pozitieUltimaParanteza; i++) {
			sir_intreParanteze[k++] = x[i];
		}
		sir_intreParanteze[k] = '\0';
		//cout << sir_intreParanteze << endl;
		strcpy(sir_intreParanteze2, sir_intreParanteze);


		string vectorParametri[500];// pozitiile pare tin nume de coloane si pozitiile impare retin  tiuri de date 
		int contorVectorParametri = 0;

		char* p11 = strtok(sir_intreParanteze, sep);

		while (p11 != NULL)
		{
			vectorParametri[contorVectorParametri++] = p11;
			p11 = strtok(NULL, sep);
		}


		Cuvant vectorCuvinte[500];
		for (int i = 0; i <= contorVectorParametri; i++) {
			if (i % 2 == 0) {

				vectorCuvinte[i].setNumeColoana(vectorParametri[i]);
			}
			else {
				if ("int" == vectorParametri[i]) {
					vectorCuvinte[i].intreg();
				}
				else if ("float" == vectorParametri[i]) {
					vectorCuvinte[i].flotant();

				}
				else if ("varchar" == vectorParametri[i]) {
					vectorCuvinte[i].varchar();

				}

			}

		}

		for (int i = 0; i < contorVectorParametri; i++) {
			//vectorCuvinte[i].afisareInformatiiCuvantCheie();
			//cout << endl;
		}

		//cout << sir_intreParanteze2 << endl;



		//char s1[232];
		//strcpy(s1, s);

		//int nrcuvinteDinParanteza = 0;
		//char sep[] = " .,";
		//char* p1 = strtok(s, sep);
		//while (p1 != NULL)
		//{
		//	nrcuvinteDinParanteza++;
		//	p1 = strtok(NULL, sep);
		//}
		////cout << nrcuvinteDinParanteza << endl;
		//Cuvant* listaTipuriDateTabela = new Cuvant[nrcuvinteDinParanteza];
		//int contorLista = 0;
		//char sep1[] = " ,";
		////cout << s1 << endl;
		//char* p11 = strtok(s1, sep1);
		//while (p11 != NULL)
		//{
		//	
		//	p11 = strtok(NULL, sep1);
		//	if (contorLista % 2 == 0) {
		//		listaTipuriDateTabela[contorLista].setNumeColoana((string)p11);
		//	}
		//	else {
		//		if (strcmp("int", p11) == 0) {
		//			listaTipuriDateTabela[contorLista].intreg();
		//		}
		//		else if (strcmp("float", p11) == 0) {
		//			listaTipuriDateTabela[contorLista].flotant();

		//		}
		//		else if (strcmp("varchar", p11) == 0) {
		//			listaTipuriDateTabela[contorLista].varchar();

		//		}
		//	}
		//	contorLista++;
		//}
	//cout << contorLista << endl;






		bool okFinal = 0;


		if (create.getPozitie() < 0 || table.getPozitie() < 0 || numetabela.getCuvant().length() <= 0 || pozitiePunctSiVirgula == -1 || pozitieUltimaParanteza == -1 || pozitePrimaParanteza == -1 || contorVectorParametri <= 0) {


			cout << "Eroare  nu ai scris create sau table sau nume de tabela sau ai omis ; sau nu ai deschis si inchis paranteze " << endl;


			return NULL;
		}
		else {

			if (create.getPozitie() < table.getPozitie() &&
				table.getPozitie() < numetabela.getPozitie() &&
				ok_numeTabela == 1 &&
				contorVectorParametri >= 2 &&
				pozitePrimaParanteza < pozitieUltimaParanteza &&
				pozitieUltimaParanteza < pozitiePunctSiVirgula  &&
				numetabela.getCuvant().length()>0 &&
				numetabela.getPozitie() < pozitePrimaParanteza
				)

			{


				cout << "tabela creata cu succes" << endl;

				Tabela * t = new Tabela();
				t->numeTabela = numetabela.getCuvant();
				t->nrColoane = contorVectorParametri / 2;

				t->coloane = new string[t->nrColoane];
				//cout << t->nrColoane << endl;
				int contorColoane = 0;
				for (int i = 0; i < contorVectorParametri; i++) {
					if (i % 2 != 0) {


						t->coloane[contorColoane] = vectorParametri[i];
						//	cout << t->coloane[contorColoane] << endl;
						contorColoane++;
					}
				}

				for (int i = 0; i < contorVectorParametri; i++) {

					//cout << vectorCuvinte[i].getCuvant() << endl;

					if (i % 2 != 0) {
						if (vectorCuvinte[i].getCuvant() == "float") {
							t->nrColoaneFloat++;
						}
						else if (vectorCuvinte[i].getCuvant() == "int") {
							t->nrColoaneIntreg++;
						}
						else if (vectorCuvinte[i].getCuvant() == "varchar") {
							t->nrColoaneString++;
						}


					}

				}

				//cout << t->nrColoane << endl;
				//cout << t->nrColoaneFloat << endl;
				//cout << t->nrColoaneIntreg << endl;
				//cout << t->nrColoaneString << endl;



				if (t->nrColoaneFloat > 0) {
					t->coloaneFloat = new float*[t->nrColoaneFloat];
				}

				if (t->nrColoaneIntreg > 0) {
					t->coloaneIntregi = new int *[t->nrColoaneIntreg];
				}

				if (t->nrColoaneString > 0) {
					t->coloaneString = new string *[t->nrColoaneString];
				}


				return t;
			}
			else {
				cout << "Eroare nu ai respectat ordinea scrierii operatoiilor ai scris table ianinte de create sau ai deschis si inchis prost parantezele sau nu ai [us punct si virgula unde trebuie " << endl;
				return NULL;
			}


		}





		//cout << pozitieCreate << endl;
		//cout << aparitiiSpatiuPanaInCreate << endl;
		//cout << okCreate << endl;

		//return okCreate;
		return 0;
	}




	void inserare(string x) {
		for (int i = 0; i < x.length(); i++) {
			x[i] = transformaTotInLitereMici(x[i]);
		}
		int pozitePrimaParanteza = -1;
		int pozitieUltimaParanteza = -1;
		int  pozitiePunctSiVirgula = -1;

		for (int i = 0; i < x.length(); i++) {
			if (x[i] == '(') {
				pozitePrimaParanteza = i;
				break;
			}
		}

		for (int i = x.length(); i >= 0; i--) {
			if (x[i] == ')') {
				pozitieUltimaParanteza = i;
				break;
			}
		}

		for (int i = 0; i < x.length(); i++) {
			if (x[i] == ';') {
				pozitiePunctSiVirgula = i;
				break;
			}
		}



		Cuvant insert;
		insert.insert();
		insert.setPozitieInComanda(x.find(insert.getCuvant()));

		Cuvant intoo;
		intoo._into();
		intoo.setPozitieInComanda(x.find(intoo.getCuvant()));


Cuvant values;
values.values();
values.setPozitieInComanda(x.find(values.getCuvant()));


cout << insert.getPozitie() << endl;


if (insert.getPozitie() < intoo.getPozitie() && intoo.getPozitie() < values.getPozitie()) {
	cout << "inserare corecta" << endl;
}

//am verificat doar ordinea cuvintelor cheie in  linia de comanda ... 
//functia inca nu insereaza doar verifica ordinea 
	}


	bool  drop_table(string x) {
		for (int i = 0; i < x.length(); i++) {
			x[i] = transformaTotInLitereMici(x[i]);
		}

		Cuvant drop;
		drop.drop();
		drop.setPozitieInComanda(x.find(drop.getCuvant()));

		Cuvant table;
		table.table();
		table.setPozitieInComanda(x.find(table.getCuvant()));


		int pozitieNumeTabela = 0;

		pozitieNumeTabela = x.find(numeTabela);
		//	cout << t->numeTabela << endl;
			//cout << pozitieNumeTabela << endl;

		if (drop.getPozitie() < table.getPozitie() && numeTabela.length() > 0) {
			cout << "Stergerea corecta" << endl;
		}

		//am  verficat oridnea cuvintelor cheie si daca exista nume de tabela 
		return 0;
	}












	//string numeTabela;
	//int nrLinii_nrObiecte = 0;
	//int nrColoane; // 4
	//string* coloane;// int string string float 
	//int  nrColoaneString = 0; //2
	//string** coloaneString = NULL;//nume prenume
	//int nrColoaneFloat = 0; // 1
	//float** coloaneFloat = NULL;//  note
	//int nrColoaneIntreg = 0;//1
	//int** coloaneIntregi = NULL;//id




	// Crearea  unei tabele Generice goale 
	Tabela() {
		numeTabela = "na";
		nrLinii_nrObiecte = 0;
		nrColoane = 0;
		coloane = NULL;
		numeColoane = NULL;

		nrColoaneString = NULL;
		coloaneString = NULL;

		coloaneFloat = NULL;
		nrColoaneFloat = 0;

		nrColoaneIntreg = 0;
		coloaneIntregi = NULL;

	}



	// Crearea unei tabele generice si initializarea n coloane de diferite tipuri 
	// 
	Tabela(string numeTabela, int nrColoane, string* tipColoane, string* numeColoane) {


		this->numeTabela = numeTabela;
		this->nrColoane = nrColoane; // coloane totale din tabela 
		int nrCS = 0;
		int nrCI = 0;
		int nrCF = 0;
		this->coloane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->coloane[i] = tipColoane[i];
		}
		//contorizam numarul de colaone de tip int string float 
		for (int i = 0; i < nrColoane; i++) {
			if (strcmpi(tipColoane[i].c_str(), "string") == 0)   {
				nrCS++;
			}
			else if (strcmpi(tipColoane[i].c_str(), "int") == 0) {

				nrCI++;
				}
			else if (strcmpi(tipColoane[i].c_str(), "float") == 0) {
				nrCF++;
			}

		}
		this->numeColoane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->numeColoane[i] = numeColoane[i];
		}


		// alocare de coloane in fucntie de tip 
		this->nrColoaneFloat = nrCF;
		this->coloaneFloat = new float*[nrCF];

		for (int i = 0; i < nrColoaneFloat; i++) {
			this->coloaneFloat[i] = NULL;
		}


		this->nrColoaneIntreg = nrCI;
		this->coloaneIntregi = new int*[nrCI];
		for (int i = 0; i < nrColoaneIntreg; i++) {
			this->coloaneIntregi[i] = NULL;
		}


		this->nrColoaneString = nrCS;
		this->coloaneString = new string*[nrCS];
		for (int i = 0; i < nrColoaneString; i++) {
			this->coloaneString[i] = NULL;
		}



	}




	//cosnt copiere 
	Tabela(const Tabela& sursa) {
		this->numeTabela = sursa.numeTabela;
		this->nrColoane = sursa.nrColoane;
		this->nrLinii_nrObiecte = sursa.nrLinii_nrObiecte;
		this->numeColoane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->numeColoane[i] = sursa.numeColoane[i];
		}
		this->coloane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->coloane[i] = sursa.coloane[i];
		}

		this->nrColoaneFloat = sursa.nrColoaneFloat;
		this->coloaneFloat = new float*[sursa.nrColoaneFloat];
		for (int i = 0; i < sursa.nrColoaneFloat; i++) {
			this->coloaneFloat[i] = new float[nrLinii_nrObiecte];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneFloat[i][j] = sursa.coloaneFloat[i][j];
			}
		}

		this->nrColoaneIntreg = sursa.nrColoaneIntreg;
		this->coloaneIntregi = new int*[sursa.nrColoaneIntreg];
		for (int i = 0; i < sursa.nrColoaneIntreg; i++) {
			this->coloaneIntregi[i] = new int[nrLinii_nrObiecte];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneIntregi[i][j] = sursa.coloaneIntregi[i][j];
			}
		}

		this->nrColoaneString = sursa.nrColoaneString;
		this->coloaneString = new string*[sursa.nrColoaneString];
		for (int i = 0; i < sursa.nrColoaneString; i++) {
			this->coloaneString[i] = new string[ nrLinii_nrObiecte ];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneString[i][j] = sursa.coloaneString[i][j];
			}
		}

	}











	// destructorul, aceasta functie poate fi folosita pentru dezalocarea unei tabele din memorie
	//dar poate fi folosita si pentru drop table ...
	//cand se sterge structura tabelei si taote dateke  tabelei din baza de date 
	virtual  ~Tabela() {
		if( numeColoane){
			delete[] numeColoane;
		}
		if (coloane) {
			delete[] coloane;
		}

		for (int i = 0; i < nrColoaneFloat; i++) {
			if (coloaneFloat[i]) {
				delete[] coloaneFloat[i];
			}
		}



		delete[] coloaneFloat;

		for (int i = 0; i < nrColoaneIntreg; i++) {
			if (coloaneIntregi[i]) {
				delete[] coloaneIntregi[i];
			}
		}
		delete[] coloaneIntregi;

		for (int i = 0; i < nrColoaneString; i++) {
			if (coloaneString[i]) {
				delete[] coloaneString[i];
			}
		}
		delete[] coloaneString;



	}







	//op=
	Tabela& operator= (const Tabela& sursa) {

		if (numeColoane) {
			delete[] numeColoane;
		}
		if (coloane) {
			delete[] coloane;
		}

		for (int i = 0; i < nrColoaneFloat; i++) {
			if (coloaneFloat[i]) {
				delete[] coloaneFloat[i];
			}
		}



		delete[] coloaneFloat;

		for (int i = 0; i < nrColoaneIntreg; i++) {
			if (coloaneIntregi[i]) {
				delete[] coloaneIntregi[i];
			}
		}
		delete[] coloaneIntregi;

		for (int i = 0; i < nrColoaneString; i++) {
			if (coloaneString[i]) {
				delete[] coloaneString[i];
			}
		}
		delete[] coloaneString;

		this->numeTabela = sursa.numeTabela;
		this->nrColoane = sursa.nrColoane;
		this->nrLinii_nrObiecte = sursa.nrLinii_nrObiecte;
		this->numeColoane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->numeColoane[i] = sursa.numeColoane[i];
		}
		this->coloane = new string[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->coloane[i] = sursa.coloane[i];
		}

		this->nrColoaneFloat = sursa.nrColoaneFloat;
		this->coloaneFloat = new float*[sursa.nrColoaneFloat];
		for (int i = 0; i < sursa.nrColoaneFloat; i++) {
			this->coloaneFloat[i] = new float[nrLinii_nrObiecte];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneFloat[i][j] = sursa.coloaneFloat[i][j];
			}
		}

		this->nrColoaneIntreg = sursa.nrColoaneIntreg;
		this->coloaneIntregi = new int*[sursa.nrColoaneIntreg];
		for (int i = 0; i < sursa.nrColoaneIntreg; i++) {
			this->coloaneIntregi[i] = new int[nrLinii_nrObiecte];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneIntregi[i][j] = sursa.coloaneIntregi[i][j];
			}
		}

		this->nrColoaneString = sursa.nrColoaneString;
		this->coloaneString = new string*[sursa.nrColoaneString];
		for (int i = 0; i < sursa.nrColoaneString; i++) {
			this->coloaneString[i] = new string[nrLinii_nrObiecte];

			for (int j = 0; j < nrLinii_nrObiecte; j++) {
				this->coloaneString[i][j] = sursa.coloaneString[i][j];
			}
		}


		return *this;
	}



	
	
	// aceasta functie insereaza in tabela un rand...
	//functie ajutatoare pt linia de cod: insert into tablename (cod, nume, medie ) values ( 1, "Gigel", 7.8);
	void insert(string numeTabela) {

		if (strcmpi(numeTabela.c_str(), this->numeTabela.c_str()) == 0) {

			//incomplet  

			for (int i = 0; i < nrLinii_nrObiecte; i++) {



			}

		}

	}



	virtual void informatiiTabela() {
		cout << "Tabela: " << numeTabela << endl;
		cout << "Cu coloanele: ";
		for (int i = 0; i < nrColoane; i++) {
			if( i!= nrColoane-1)
			cout << numeColoane[i] << " (" << coloane[i] << ")" << ", ";
			else {
				cout << numeColoane[i] << " (" << coloane[i] << ")";
			}
		}
		cout << endl;


	}

	virtual void  resetare() {
		*this = Tabela();
	}


	virtual void tipTabela() {
		cout << "Tabela normala" << endl;
	}


};


enum Grad{ admin, normal_user,  beginer_user  };

class User:public IGestiuneTabela
{
	string nume="na";
	Grad grad=normal_user;

public:

	 void  resetare() {
		*this = User();
	}

	User() {

	}
	User(string n, Grad g) {
		nume = n;
		grad = g;
	}


	User(User & s) {
		nume = s.nume;
		grad = s.grad;
	}

	void informatiiTabela() {

		cout << nume << " ";
		switch (grad)
		{
		case 0: cout << " admin" << endl;
			break;

		case 1: cout << " user normal" << endl;
			break;
		case 2: cout << " user incepator" << endl;
			break;
		default:
			cout << "default" << endl;
			break;
		}
	}

	
};


// COMPUNERE SI MOSTENIRE 
class Tabela_gestionata:public Tabela
{
	int nrUseri;
	User* useri;

public:

	 void  resetare() {
		*this = Tabela_gestionata();
	}

	Tabela_gestionata() {
		nrUseri = 0;
		useri = NULL;
	}


	Tabela_gestionata(string numeTabela, int nrColoane, string* tipColoane, string* numeColoane, int nru, User* us) :Tabela(numeTabela, nrColoane, tipColoane, numeColoane)
	{
		nrUseri = nru;
		useri = new User[nrUseri];
		for (int i = 0; i < nrUseri; i++) {
			useri[i] = us[i];
		}

	}


	Tabela_gestionata(const Tabela_gestionata & s) :Tabela(s) {

		nrUseri = s.nrUseri;
		useri = new User[nrUseri];
		for (int i = 0; i < nrUseri; i++) {
			useri[i] = s.useri[i];
		}
	}


	Tabela_gestionata& operator= (const Tabela_gestionata & s)  {

		Tabela::operator=(s);
		if (useri) {
			delete[] useri;
		}
		nrUseri = s.nrUseri;
		useri = new User[nrUseri];
		for (int i = 0; i < nrUseri; i++) {
			useri[i] = s.useri[i];
		}


		return *this;
	}



	~Tabela_gestionata() {

		if (useri) {
			delete[] useri;
		}

	 }



	 void informatiiTabela() {
		 Tabela::informatiiTabela();
		 cout << "Tabela are " << nrUseri << " useri" << endl;
		 for (int i = 0; i < nrUseri; i++) {
			 useri[i].informatiiTabela();
		 }


	}


	 void tipTabela() {
		 cout << "Tabela gestionata" << endl;
	 }



};



void main() {


	// FAZAAAA I 
	Tabela* t=NULL;

	// codul de sql poate fi scris si cu litere mari si cu litere mici 


	//        0123456789
	//                                   0   1    2      3        4         5 
	string x = " CREATE TABLE    Persons  ( id int, nume varchar, prenume varchar );";//
	// se presupe ca x este citit de la tastatura
	t=(*t).creareTabela(x);

	// cout << t->coloane[2] << endl;

	x = "Insert into persons values(121,  gigel, costel)";
	(*t).inserare(x);

	x = "Drop table persons";
	(*t).drop_table(x);


	//	char s[323];




	//                                |    |     |    |    |    | 
	//UPdateuri aduse pt faza 2 si 3 \|/  \|/   \|/  \|/  \|/  \|/
	//                                '    '     '    '    '    '
	
	
	
	Tabela t0;// apelul asta  ne ajuta la alocarea de memorie pe viitor pt tabele 

	//Crearea unei tabele generice si initializarea n coloane de diferite tipuri
	// apelul asta de mai jos ne ar ajuta la urmatoarea linie de cod: create table studenti ( int cod, string nume, float medie);
	Tabela t1("Studenti", 3, new string[3]{ "int","string","float" },new string[3]{ "cod","nume" ,"medie" });


	Tabela t2(t1);// acest apel ajuta la copierea unei tabele, 
	//poate fi util mai departe in proiect cand dam ca parametru copii 
	// sau cu ajutorul lui poti face un back up 


	//operator = ... aceasta ne ajuta pe viitor in proiect sa prelucram tabelele 
	// sa facem 2 tabele la fel... t0=t1;; t1 va prelua datele lui t1... si ca structura de tabela si ca date fizice din tabela 
	// in  sgbd  ar fi tot echivalentul unui backup 

	t0 = t1;

	//t2.informatiiTabela();



	// SALVEAZAAA TOT DESPRE BAZA DE DATE aceste fucntii si prea ia TOT
	Tabela t3;
	// salvarea tabelei in binar 
	// simuleaza salvarea tabelei in baza de date 
	ofstream  fisierBinarScriere;
	fisierBinarScriere.open("tabela1.dat", ios::binary);
	t1.salvareInBinar(fisierBinarScriere);
	fisierBinarScriere.close();



	//preluare in tabela din fisier binar 
	
	ifstream  fisierBinarCitire;
	fisierBinarCitire.open("tabela1.dat", ios::binary);
	t3.preluareDinBinar(fisierBinarCitire);
	fisierBinarCitire.close();
	cout << "DATELE DE SPRE T3 SUNT" << endl;


	t3.informatiiTabela();
	cout << "------------------------" << endl;




	string  xx = "Gabi";
	string yy = "gabi";
	// cout << (strcmpi( xx.c_str(), yy.c_str() )==0)  << endl;


	User u1("Gigel", admin);
	User u2("Titel", normal_user);
	User  vectorUseri[2] = { u1, u2 };

	Tabela_gestionata tg;
	Tabela_gestionata tg1("Studenti", 3, new string[3]{ "int","string","float" }, new string[3]{ "cod","nume" ,"medie" }, 2, vectorUseri);
	Tabela_gestionata tg2(tg1);
	tg = tg1;

	//tg1.informatiiTabela();

	IGestiuneTabela * vectorPointeri[5] = { &t1, &u1, &tg1 };
	
	for (int i = 0; i < 3; i++) {
		//vectorPointeri[i]->informatiiTabela();
		//vectorPointeri[i]->resetare();
	}

	Tabela * vectorTabele[2] = { &tg1, &t2 };
	for (int i = 0; i < 2; i++) {
		vectorTabele[i]->tipTabela(); // fucntie virtuala normala 
	}



	vector<Tabela> vTabele;
	vTabele.push_back(t1);
	vTabele.push_back(t2);
	
	vTabele.pop_back();
	for (int i = 0; i < vTabele.size(); i++) {
		vTabele[i].informatiiTabela();
	}


	list<IGestiuneTabela*> listaInformatii;
	listaInformatii.push_back(&u1);
	listaInformatii.push_back(&t1);
	listaInformatii.push_front(&tg1);
	listaInformatii.push_front(&tg1);
	listaInformatii.pop_back();
	listaInformatii.pop_front();


	list<IGestiuneTabela*>::iterator it;
	
	for (it= listaInformatii.begin() ; it!= listaInformatii.end(); it++) {
		(*it)->informatiiTabela();
	}




	map< string, Tabela  > mapa;
	mapa.insert(pair<string, Tabela> ("tabela1" ,t1) );
	mapa.insert(pair<string, Tabela>("tabela2", t1));

	map<string, Tabela>::iterator it1;
	for (it1 = mapa.begin(); it1 != mapa.end(); it1++) {
		cout <<  it1->first << endl;
		
		it1->second.informatiiTabela();
	}




}