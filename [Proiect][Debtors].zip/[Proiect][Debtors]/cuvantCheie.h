#include<iostream>
using namespace std;



class Cuvant {

private:
	string cuvant;
	int poziteInComanda;

	int  tip;//0-nespecificat na , 1-cuvant cheie, 2-nume de tipdata ,3-nume de tabela, 4 nume de coloana, 


public:

	Cuvant() {
		cuvant = "na ";
		poziteInComanda = -1;
		tip = 0;
	}

	void create() {
		cuvant = "create ";
		tip = 1;
	}


	void insert() {
		cuvant = "insert ";
		tip = 1;
	}
	void _into() {
		cuvant = "into ";
		tip = 1;
	}
	void varchar() {
		cuvant = "varchar";
		tip = 2;
	}

	void values() {
		cuvant = "values";
		tip = 1;
	}

	void intreg() {
		cuvant = "int";
		tip = 2;
	}

	void flotant() {
		cuvant = "float";
		tip = 2;
	}


	void table() {
		cuvant = "table ";
		tip = 1;
	}

	void select() {
		cuvant = "select ";
		tip = 1;
	}

	void update() {
		cuvant = "update ";
		tip = 1;
	}

	void _delete() {
		cuvant = "delete ";
		tip = 1;
	}

	void drop() {
		cuvant = "drop ";
		tip = 1;
	}

	void setPozitieInComanda(int pozitieNoua) {
		if (pozitieNoua >= 0) {
			poziteInComanda = pozitieNoua;
		}
	}

	void setNumeTabela(string numeTabelaNou) {
		if (numeTabelaNou.length() > 0) {
			cuvant = numeTabelaNou;
			tip = 3;
		}
	}


	void setNumeColoana(string numecolaoana) {
		if (numecolaoana.length() > 0) {
			cuvant = numecolaoana;
			tip = 4;
		}
	}



	int getPozitie() {
		return poziteInComanda;
	}
	string getCuvant() {
		return cuvant;
	}
	int  getTip() {
		return tip;
	}

	void afisareInformatiiCuvantCheie() {
		cout << "Cuvant:"<<cuvant << endl;
		cout << "Pozitie " << poziteInComanda << endl;
		switch ( tip)
		{
		case 0:cout << "Tip  nespecificat" << endl;
			break;
		case 1:cout << "Tip  cuvant chie" << endl;
			break;
		case 2:cout << "Tip  tip de data" << endl;
			break;

		case 3:cout << "Tip  nume tabela" << endl;
			break;
		case 4:cout << "Tip  nume coloana" << endl;
			break;
		default:
			cout << "Tip  a intrat default" << endl;
			break;
		}
	}

};


