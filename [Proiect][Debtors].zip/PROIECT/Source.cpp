#include<iostream>
#include<string>
#pragma warning(disable:4996)
#include"cuvantCheie.h"
using namespace std;




// 0123456789ABCD
//  CREATE TABLE Persons   ( int, varchar(255), varchar(255), varchar(255), varchar(255))     ;
/*
1. cauta subsirul create intr un sir  si verifica sa fie primul 
2. daca ai gasit  create cauta table si vezi sa fie primul dupa create 
3. daca ai gasit SI create si Table ... cauta un sir oarecare dupa create table  
4. 

*/


// id    nume   prenume
// 0      gigel  ion
// 1       ionel  gigi


class Tabela {

public:
	

	string numeTabela;
	int nrLinii_nrObiecte=0;
	int nrColoane; // 4
	string* coloane;// int string string float 


	int  nrColoaneString=0; //2
	string** coloaneString=NULL;//nume prenume

	int nrColoaneFloat = 0; // 1
	float** coloaneFloat=NULL;//  note

	int nrColoaneIntreg=0;//1
	int** coloaneIntregi=NULL;//id

public:









};

Tabela* t;

char transformaTotInLitereMici(char c) {
	if (c <= 'Z' && c >= 'A')
		return c - ('Z' - 'z');
	return c;
}

Tabela* creareTabela( string x) {

	for (int i = 0; i < x.length(); i++) {
		x[i] = transformaTotInLitereMici(x[i]);
	}


	//int pozitieCreate= x.find("create");
	//bool okCreate = 0;
	////cout << pozitieCreate << endl;
	//int  aparitiiSpatiuPanaInCreate = 0;
	//if (pozitieCreate >= 0) {

	//	for (int i = 0; i < pozitieCreate; i++) {
	//		if (x[i] == ' ') {
	//			aparitiiSpatiuPanaInCreate++;
	//		}
	//	}

	//}
	//if (pozitieCreate == aparitiiSpatiuPanaInCreate) {
	//	okCreate = 1;
	//}


	int pozitePrimaParanteza = -1;
	int pozitieUltimaParanteza = -1;
	int  pozitiePunctSiVirgula = -1;

	for (int i = 0; i < x.length(); i++) {
		if (x[i] == '(') {
			pozitePrimaParanteza = i;
			break;
		}
	}

	for (int i = x.length();  i >=0; i--) {
		if (x[i] == ')') {
			pozitieUltimaParanteza = i;
			break;
		}
	}

	for (int i = 0; i < x.length(); i++) {
		if (x[i] == ';') {
			pozitiePunctSiVirgula = i;
			break;
		}
	}



	Cuvant create;
	create.create();
	create.setPozitieInComanda(x.find(create.getCuvant()));

	Cuvant table;
	table.table();
	table.setPozitieInComanda(x.find(table.getCuvant()));



	//table.afisareInformatiiCuvantCheie();



	int p = table.getPozitie() + table.getCuvant().length();
	Cuvant numetabela;

	//cout << x[p] << endl;
	char numetabelachar[500];
	int contor_numetabelachar = 0;
	for (int i = p; i < pozitePrimaParanteza; i++) {
			numetabelachar[contor_numetabelachar++] = x[i];
	}
	numetabelachar[contor_numetabelachar] = '\0';

	//cout << numetabelachar << endl;
	
	int contorCuvinteNumeTabela = 0;
	char sep[] = " .,)";
	 char* p1 = strtok( numetabelachar, sep);
while (p1 != NULL)
{
	contorCuvinteNumeTabela++;
	p1 = strtok(NULL, sep);
}

	bool ok_numeTabela = 0;
	if (contorCuvinteNumeTabela == 1) {
		ok_numeTabela = true;
	}


	//cout << numeTabela.length() << endl;

	if (ok_numeTabela == 1) {
		numetabela.setNumeTabela( numetabelachar);
numetabela.setPozitieInComanda(x.find(numetabelachar));

	}
	//numetabela.afisareInformatiiCuvantCheie();

	
	 
	int pozitiiVirgule[500];
	int nrvirgule = 0;
	for (int i = pozitePrimaParanteza; i < pozitieUltimaParanteza; i++) {

		if (x[i] == ',') {
			pozitiiVirgule[nrvirgule++] = i;
		}
	}

	//for (int i = 0; i < nrvirgule; i++) {
	////	cout << pozitiiVirgule[i] << endl;
	//}


	char sir_intreParanteze[500];
	char sir_intreParanteze2[500];

	
	int  k = 0;
	for (int i = pozitePrimaParanteza+1; i <= pozitieUltimaParanteza; i++) {
		sir_intreParanteze[k++] = x[i];
	}
	sir_intreParanteze[k] = '\0';
	//cout << sir_intreParanteze << endl;
	strcpy(sir_intreParanteze2, sir_intreParanteze);
	

	string vectorParametri[500];// pozitiile pare tin nume de coloane si pozitiile impare retin  tiuri de date 
	int contorVectorParametri = 0;

	char* p11 = strtok(sir_intreParanteze, sep);

	while (p11 != NULL)
	{
		vectorParametri[contorVectorParametri++] = p11;
		p11 = strtok(NULL, sep);
	}


	Cuvant vectorCuvinte[500];
	for (int i = 0; i <= contorVectorParametri; i++) {
		if (i % 2 == 0) {

			vectorCuvinte[i].setNumeColoana(vectorParametri[i]);
		}
		else {
			if ("int" == vectorParametri[i]) {
				vectorCuvinte[i].intreg();
			}
			else if ("float" == vectorParametri[i]) {
				vectorCuvinte[i].flotant();

			}
			else if ("varchar" == vectorParametri[i]) {
				vectorCuvinte[i].varchar();

			}

		}
	
	}

	for (int i = 0; i < contorVectorParametri; i++) {
		//vectorCuvinte[i].afisareInformatiiCuvantCheie();
		//cout << endl;
	}

	//cout << sir_intreParanteze2 << endl;



	//char s1[232];
	//strcpy(s1, s);

	//int nrcuvinteDinParanteza = 0;
	//char sep[] = " .,";
	//char* p1 = strtok(s, sep);
	//while (p1 != NULL)
	//{
	//	nrcuvinteDinParanteza++;
	//	p1 = strtok(NULL, sep);
	//}
	////cout << nrcuvinteDinParanteza << endl;
	//Cuvant* listaTipuriDateTabela = new Cuvant[nrcuvinteDinParanteza];
	//int contorLista = 0;
	//char sep1[] = " ,";
	////cout << s1 << endl;
	//char* p11 = strtok(s1, sep1);
	//while (p11 != NULL)
	//{
	//	
	//	p11 = strtok(NULL, sep1);
	//	if (contorLista % 2 == 0) {
	//		listaTipuriDateTabela[contorLista].setNumeColoana((string)p11);
	//	}
	//	else {
	//		if (strcmp("int", p11) == 0) {
	//			listaTipuriDateTabela[contorLista].intreg();
	//		}
	//		else if (strcmp("float", p11) == 0) {
	//			listaTipuriDateTabela[contorLista].flotant();

	//		}
	//		else if (strcmp("varchar", p11) == 0) {
	//			listaTipuriDateTabela[contorLista].varchar();

	//		}
	//	}
	//	contorLista++;
	//}
//cout << contorLista << endl;






	bool okFinal = 0;


	if (create.getPozitie() < 0 || table.getPozitie()<0 || numetabela.getCuvant().length()<=0 || pozitiePunctSiVirgula==-1 || pozitieUltimaParanteza ==-1 || pozitePrimaParanteza==-1  || contorVectorParametri<=0) {

		
		cout << "Eroare  nu ai scris create sau table sau nume de tabela sau ai omis ; sau nu ai deschis si inchis paranteze " << endl;


		return NULL;
	}
	else {

		if (create.getPozitie() < table.getPozitie() &&
			table.getPozitie() < numetabela.getPozitie() &&
			ok_numeTabela == 1 &&
			contorVectorParametri >= 2 &&
			pozitePrimaParanteza < pozitieUltimaParanteza && 
			pozitieUltimaParanteza < pozitiePunctSiVirgula  &&
			numetabela.getCuvant().length()>0   &&
			numetabela.getPozitie()< pozitePrimaParanteza
			) 
		
		{


			cout << "tabela creata cu succes" << endl;

			Tabela * t = new Tabela ();
			t->numeTabela = numetabela.getCuvant();
			t->nrColoane = contorVectorParametri / 2;

			t->coloane = new string[t->nrColoane];
			//cout << t->nrColoane << endl;
			int contorColoane=0;
			for (int i = 0; i < contorVectorParametri; i++) {
				if (i % 2 != 0) {
			
			
					t->coloane[contorColoane] = vectorParametri[i];
				//	cout << t->coloane[contorColoane] << endl;
					contorColoane++;
				}
			}

			for (int i = 0; i < contorVectorParametri; i++) {

				//cout << vectorCuvinte[i].getCuvant() << endl;
				
				if (i % 2 != 0) {
					if (vectorCuvinte[i].getCuvant() == "float") {
						t->nrColoaneFloat++;
					}
					else if (vectorCuvinte[i].getCuvant() == "int") {
						t->nrColoaneIntreg++;
					}
					else if (vectorCuvinte[i].getCuvant() == "varchar") {
						t->nrColoaneString++;
					}


				}

			}

			//cout << t->nrColoane << endl;
			//cout << t->nrColoaneFloat << endl;
			//cout << t->nrColoaneIntreg << endl;
			//cout << t->nrColoaneString << endl;



			if (t->nrColoaneFloat > 0) {
				t->coloaneFloat = new float*[t->nrColoaneFloat];
			}
			
			if (t->nrColoaneIntreg > 0) {
				t->coloaneIntregi = new int * [t->nrColoaneIntreg];
			}

			if (t->nrColoaneString > 0) {
				t->coloaneString = new string * [t->nrColoaneString];
			}


			return t;
		}
		else {
			cout << "Eroare nu ai respectat ordinea scrierii operatoiilor ai scris table ianinte de create sau ai deschis si inchis prost parantezele sau nu ai [us punct si virgula unde trebuie " << endl;
			return NULL;
		}


	}





	//cout << pozitieCreate << endl;
	//cout << aparitiiSpatiuPanaInCreate << endl;
	//cout << okCreate << endl;

	//return okCreate;
	return 0;
}




void inserare(string x) {
	for (int i = 0; i < x.length(); i++) {
		x[i] = transformaTotInLitereMici(x[i]);
	}
	int pozitePrimaParanteza = -1;
	int pozitieUltimaParanteza = -1;
	int  pozitiePunctSiVirgula = -1;

	for (int i = 0; i < x.length(); i++) {
		if (x[i] == '(') {
			pozitePrimaParanteza = i;
			break;
		}
	}

	for (int i = x.length(); i >= 0; i--) {
		if (x[i] == ')') {
			pozitieUltimaParanteza = i;
			break;
		}
	}

	for (int i = 0; i < x.length(); i++) {
		if (x[i] == ';') {
			pozitiePunctSiVirgula = i;
			break;
		}
	}



	Cuvant insert;
	insert.insert();
	insert.setPozitieInComanda(x.find(insert.getCuvant()));

	Cuvant intoo;
	intoo._into();
	intoo.setPozitieInComanda(x.find(intoo.getCuvant()));


	Cuvant values;
	values.values();
	values.setPozitieInComanda(x.find(values.getCuvant()));


	cout << insert.getPozitie() << endl;


	if (insert.getPozitie() < intoo.getPozitie() && intoo.getPozitie() < values.getPozitie()) {
		cout << "inserare corecta" << endl;
	}

	//am verificat doar ordinea cuvintelor cheie in  linia de comanda ... 
	//functia inca nu insereaza doar verifica ordinea 
}


bool  drop_table(string x) {
	for (int i = 0; i < x.length(); i++) {
		x[i] = transformaTotInLitereMici(x[i]);
	}

	Cuvant drop;
	drop.drop();
	drop.setPozitieInComanda(x.find(drop.getCuvant()));

	Cuvant table;
	table.table();
	table.setPozitieInComanda(x.find(table.getCuvant()));


	int pozitieNumeTabela = 0;

	pozitieNumeTabela = x.find(t->numeTabela);
//	cout << t->numeTabela << endl;
	//cout << pozitieNumeTabela << endl;

	if (drop.getPozitie() < table.getPozitie() && t->numeTabela.length() > 0) {
		cout << "Stergerea corecta" << endl;
	}

	//am  verficat oridnea cuvintelor cheie si daca exista nume de tabela 
	return 0;
}

void main() {


	// codul de sql poate fi scris si cu litere mari si cu litere mici 

	
	//        0123456789
	//                                   0   1    2      3        4         5 
	string x=" CREATE TABLE    Persons  ( id int, nume varchar, prenume varchar );";//
	// se presupe ca x este citit de la tastatura
	 t= creareTabela(x);

	// cout << t->coloane[2] << endl;

	 x = "Insert into persons values(121,  gigel, costel)";
	inserare(  x);

	x = "Drop table persons";
	drop_table(x);


//	char s[323];


	


}